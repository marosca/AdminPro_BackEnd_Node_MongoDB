# Google-Signin-demo

Esta carpeta contiene un pequeño front-end para obtener el token de Google y probarlo contra nuestro backend server.

Recuerden que es necesario reconstruir los módulos de node, en caso de que se quiera probar localmente

```
npm install
```