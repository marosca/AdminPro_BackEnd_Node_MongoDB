module.exports.SEED = 'este-es-un-seed-dificil';

// Google
module.exports.GOOGLE_CLIENT_ID = '442737206823-dilej5tevnrv61sovd7bocf5qeafmjs3.apps.googleusercontent.com';
module.exports.GOOGLE_SECRET = '6cWrrFy8KchLLrYmg70esp7t';