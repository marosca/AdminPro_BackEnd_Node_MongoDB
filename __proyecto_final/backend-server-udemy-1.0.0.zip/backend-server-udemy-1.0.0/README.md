# Backend-Server

Este es el código necesario para establecer el backend conectado a MongoDB usando Mongoose.

Para ejecutarlo, es necesario reconstruir los módulos de node usando el comando

```
npm install
```

## Dentro de Google-Signin-demo
Existe un pequeño ejercicio para probar la autenticación de Google en un Front-End básico pero funcional.